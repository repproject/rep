from requests import get
from bs4 import BeautifulSoup
import urllib.request
#import REP_DAO                  #DB 전문 CLASS
import hyeogyu
import jiil_sample
import REP_URL

userid = 1000000001            #추후 사용하기 위해 만든

def migRetBigAreaCode():    #박지일

    print("Function migRetBigAreaCode")
    url = REP_URL.KB부동산과거시세조회URL
    soup = getBeautifulShopFromKB(url)

    for child in soup.find("select", id="부동산대지역코드"):
        if len(child) == 1 :    #쓰레기값 제외
            print(child['value']) #부동산대지역코드
            print(child.text)      #부동산대지역명
            #REP_DAO.INSERT_KMIG_KB_REGN(child['value'],child.text,'null')

def migRetMidAreaCode():    #서진철
    print("Function migRetMidAreaCode")

def migRetSmallAreaCode():  #서진철
    print("Function migRetSmallAreaCode")

def migComplex():  #서진철
    print("Function migComplex")

def migComplexTypSeq():  #서진철
    print("Function migComplexTypSeq")

def migMontlyPrice():  #기노균
    print("Function migMontlyPrice")


def getBeautifulShopFromKB(url):    #BeautifulShop Class로 특정 Page를 Return한다.
    print("Function getBeautifulShopFromKB")
    r = get(url)
    soup = BeautifulSoup(r.content.decode('utf-8', 'replace'),"html5lib")
    return soup

def main():
    migRetBigAreaCode();    # 부동산대지역코드 Migration
    migRetMidAreaCode();    # 부동산중지역코드 Migration
    migRetSmallAreaCode();  # 부동산중지역코드 Migration
    migComplex();           # 단지명(물건식별자) Migration
    migComplexTypSeq();     # 단지평형(주택형일련번호) Migration
    migMontlyPrice();       # 월별가격 Migration
    #hyeogyu.HGgetPrice();   # 혜규형 소스
    jiil_sample.JIGgetPrice() #지일 소스

if __name__ == '__main__':
    main()
