import pymysql
import REP_Main

def INSERT_KMIG_KB_REGN(KB_REGN_CD, KB_REGN_NM,UP_KB_REGN_CD):
    print(__name__)
    conn = pymysql.connect(host='localhost',user='root',password='5427',db='rep',charset='utf8')
    curs = conn.cursor()

    user_id = REP_Main.userid

    sql = """INSERT INTO KMIG_KB_REGN (KB_REGN_CD, KB_REGN_NM, UP_KB_REGN_CD, LV_CD, REG_USER_ID, REG_DTM, CHG_USER_ID, CHG_DTM) VALUES (%s,%s,%s,%s,%s,NOW(),%s,NOW())"""
    curs.execute(sql, (KB_REGN_CD, KB_REGN_NM, UP_KB_REGN_CD, "1", user_id, user_id))

    conn.commit()
    conn.close()

